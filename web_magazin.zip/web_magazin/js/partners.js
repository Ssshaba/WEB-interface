const renderItems = (date) => {
    console.log(date);
}

fetch('./db/partners.json')
    .then((respons) => respons.json())
    .then((date) => {
        renderItems(date)
    })
    .catch((error) => {
        console.log(error);
    })